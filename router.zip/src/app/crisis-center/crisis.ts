export class Crisis {
  id: number;
  name: string;
}
